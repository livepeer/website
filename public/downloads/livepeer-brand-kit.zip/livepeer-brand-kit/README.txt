Livepeer Brand Kit

Logos (SVG, scalable)
  logos/livepeer-symbol-{white,black}.svg
  logos/livepeer-wordmark-{white,black}.svg
  logos/livepeer-lockup-{white,black}.svg

  Use white variants on dark backgrounds, black variants on light.
  Never rotate, stretch, recolor, or apply effects to the logos.

Colors
  colors/livepeer-colors.txt — hex values for the brand palette.

Typography (not included)
  Favorit Pro (primary) and Favorit Mono are licensed from Dinamo Type.
  We cannot redistribute the font files. License them directly from Dinamo.

More
  Full brand guidelines:  https://livepeer.org/brand
  Questions:              https://discord.gg/livepeer

Livepeer Brand Kit

Logos (SVG, scalable)
  logos/livepeer-symbol-{white,black}.svg
  logos/livepeer-wordmark-{white,black}.svg
  logos/livepeer-lockup-{white,black}.svg

  Use white variants on dark backgrounds, black variants on light.
  Never rotate, stretch, recolor, or apply effects to the logos.

Colors
  colors/livepeer-colors.txt — hex values for the brand palette.

Typography (not included)
  Inter for everything, from Rasmus Andersson's distribution:
    https://rsms.me/inter/
  Geist Mono for code and values:
    https://vercel.com/font
  Both are free under the SIL Open Font License.

More
  Full brand guidelines:  https://livepeer.org/brand
  Questions:              https://livepeer.org/discord
